// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoAnimalAbeja.h"

void AEnemigoAnimalAbeja::BeginPlay()
{

}

void AEnemigoAnimalAbeja::Tick(float DeltaTime)
{

}
