// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoVegetalBrocoli.h"

void AEnemigoVegetalBrocoli::BeginPlay()
{

}

void AEnemigoVegetalBrocoli::Tick(float DeltaTime)
{

}
