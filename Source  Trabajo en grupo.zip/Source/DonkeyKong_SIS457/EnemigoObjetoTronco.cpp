// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoObjetoTronco.h"

void AEnemigoObjetoTronco::BeginPlay()
{

}

void AEnemigoObjetoTronco::Tick(float DeltaTime)
{

}
