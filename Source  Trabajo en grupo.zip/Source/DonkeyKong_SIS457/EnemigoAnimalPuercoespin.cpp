// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoAnimalPuercoespin.h"

void AEnemigoAnimalPuercoespin::BeginPlay()
{
}

void AEnemigoAnimalPuercoespin::Tick(float DeltaTime)
{
}
