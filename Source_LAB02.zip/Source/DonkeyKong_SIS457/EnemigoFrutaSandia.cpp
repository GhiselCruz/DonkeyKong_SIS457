// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoFrutaSandia.h"

void AEnemigoFrutaSandia::BeginPlay()
{

}

void AEnemigoFrutaSandia::Tick(float DeltaTime)
{

}
