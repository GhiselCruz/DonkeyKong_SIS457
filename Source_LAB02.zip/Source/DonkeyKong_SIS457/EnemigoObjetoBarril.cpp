// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoObjetoBarril.h"

void AEnemigoObjetoBarril::BeginPlay()
{

}

void AEnemigoObjetoBarril::Tick(float DeltaTime)
{

}
