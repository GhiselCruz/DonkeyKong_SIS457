// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoFrutaBanana.h"

void AEnemigoFrutaBanana::BeginPlay()
{

}

void AEnemigoFrutaBanana::Tick(float DeltaTime)
{

}
