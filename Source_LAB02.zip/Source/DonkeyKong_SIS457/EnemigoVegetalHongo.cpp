// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoVegetalHongo.h"

void AEnemigoVegetalHongo::BeginPlay()
{

}

void AEnemigoVegetalHongo::Tick(float DeltaTime)
{

}
