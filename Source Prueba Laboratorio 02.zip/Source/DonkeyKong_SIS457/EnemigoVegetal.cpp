// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoVegetal.h"

void AEnemigoVegetal::BeginPlay()
{

}

void AEnemigoVegetal::Tick(float DeltaTime)
{

}
