// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoAnimalDragon.h"

void AEnemigoAnimalDragon::BeginPlay()
{

}

void AEnemigoAnimalDragon::Tick(float DeltaTime)
{

}
