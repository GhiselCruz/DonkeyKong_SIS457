// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoAnimal.h"

void AEnemigoAnimal::BeginPlay()
{
}

void AEnemigoAnimal::Tick(float DeltaTime)
{
}
